# Introduction 
Code to show a Star Wars Tactical Display on a mini Oled with Arduino

# Getting Started
Tutorial : https://youtu.be/HzHRJd7rihE